//prime number
/*let i=7
let flag=true;
for(let j=2;j<=i/2;j++){
  if(i%j==0){
    flag=false;
    break;
  }

}
if(flag){
  console.log(i,"prime number");
}
else
  console.log(i,"not prime number")
*/

//Sum of Array
/*
let arr=[1,2,3,4,5,6,7,8,9,10]
let sum=0
for(let i=0;i<arr.length;i++){
  sum=sum+arr[i]
}
console.log("Sum of the array is",sum)
*/

//Max, Min of an array
/*
let a=[45,23,53,11,12,9,7,1,25]
let max=a[0]
let min=a[0]
for(let i=0;i<a.length;i++){
  if(a[i]>max){
    max=a[i]
  }
  if(a[i]<min){
    min=a[i]
  }
}
console.log("Max of the array is",max)
console.log("Min of the array is",min)
*/

//Pattern program
/*
let n = 5;
for (let i = 1; i <= n; i++) {
    let row = '';
    for (let j = 1; j <= i; j++) {
        row += '* '; // Add asterisk to the row with a space
    }
    console.log(row); // Print the row
}
*/

//Count number of occurances of the term in an array
/*
let a = [1, 2, 3, 43, 3, 2, 1, 43, 54, 43, 43];
for (let i = 0; i < a.length; i++) {
  let count = 1;
  for (let j = i + 1; j < a.length; j++) {
    if (a[i] == a[j]) {
      count++;
      a[j] = -1;
    }
  }
  if (a[i] != -1) {
    console.log("Number of occurances of", a[i], "is", count);
  }
}
*/

//Fibinocci series
/*
let a=0
let b=1
//let n=prompt("Enter the number of terms in fibinocci series")
//parseInt(n)
n=10
console.log(a)
console.log(b)
for(let i=2;i<=n;i++){
  let c=a+b
  console.log(c)
  a=b
  b=c
}
*/

//Factorial of a number
/*
let n=5
let fact=1
while(n>0){
  fact=fact*n
  n--
}
console.log(fact)
*/

//Reverse a number
/*
let n=198
let rev=0
while(n>0){
  rem=n%10
  rev=rev*10+rem
  n=Math.floor(n/10)
}
console.log(rev)
*/

//Palindrome number
/*
let n=198
let dup=n
let rev=0
while(n>0){
  rem=n%10
  rev=rev*10+rem
  n=Math.floor(n/10)
}
if(rev==dup){
  console.log("Palindrome")
}
else
  console.log("Not a Palindrome")
  */

//Armstrong number
/*
let n=153
let rev=0
let dup=n
while(n>0){
  rem=n%10
  rev=rev+rem*rem*rem
  n=Math.floor(n/10)
}
if(dup==rev){
  console.log("Armstrong number")
}
else
  console.log("Not a Armstrong number")
  */

//String palindrome
/*
let n="malayalam"
let rev=""
for(let i=n.length-1;i>=0;i--){
  rev=rev+n[i]
}
if(n==rev){
  console.log("Palindrome")
}
else
  console.log("Not a Palindrome")
  */

//String reverse
/*
let n="shreeprabha"
let rev=""
for(let i=n.length-1;i>=0;i--){
  rev=rev+n[i]
}
console.log(rev)
*/

//Count number of character in a string

let a = "shreeprabha";
let count = {};

for (let i = 0; i < a.length; i++) {
  if (count[a[i]]) {
    count[a[i]]++;
  } else {
    count[a[i]] = 1;
  }
}

for (let char in count) {
  console.log(char, "=", count[char]);
}
